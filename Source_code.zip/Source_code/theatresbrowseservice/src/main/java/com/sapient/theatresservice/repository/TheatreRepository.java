package com.sapient.theatresservice.repository;

import com.sapient.theatresservice.entities.Theatre;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface TheatreRepository extends CrudRepository<Theatre, Long> {
    Optional<List<Theatre>> findByCity(String city);
}
