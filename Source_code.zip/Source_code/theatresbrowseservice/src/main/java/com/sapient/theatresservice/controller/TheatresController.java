package com.sapient.theatresservice.controller;

import com.sapient.theatresservice.entities.Theatre;
import com.sapient.theatresservice.model.SeatInventoryUpdateRequest;
import com.sapient.theatresservice.model.TheatreCreationRequest;
import com.sapient.theatresservice.service.TheatresService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/api/theatres/v1")
public class TheatresController {

    private final TheatresService theatresService;

    public TheatresController(TheatresService theatresBrowsingService) {
        this.theatresService = theatresBrowsingService;
    }

    @GetMapping("/{movieTitle}/{country}/{city}/{date}")
    public ResponseEntity<List<Theatre>> browseTheatres(@PathVariable final String movieTitle, @PathVariable final String country, @PathVariable final String city, @PathVariable final Date date) {
        return ResponseEntity.ok(theatresService.getTheatres(movieTitle, country, city, date));
    }

    @GetMapping("/{city}")
    public ResponseEntity<List<Theatre>> browseTheatres(@PathVariable final String city) {
        return ResponseEntity.ok(theatresService.getTheatres(city));
    }

    @PostMapping
    public ResponseEntity<Theatre> createTheatre(@RequestBody final TheatreCreationRequest request) {
        return ResponseEntity.ok(theatresService.createTheatre(request));
    }

    @PutMapping("/{theatreId}/screen/{screenId}")
    public ResponseEntity<Theatre> updateSeats(@PathVariable final Long theatreId, @PathVariable final Long screenId, @RequestBody final SeatInventoryUpdateRequest request) {
        return ResponseEntity.ok(theatresService.updateSeatInventory(theatreId, screenId, request));
    }

    @GetMapping("/{country}/{city}/{movieTitle}")
    public ResponseEntity<List<Theatre>> getTheatres( @PathVariable final String country, @PathVariable final String city, @PathVariable final String movieTitle) {
        return ResponseEntity.ok(theatresService.getTheatres(movieTitle, country, city));
    }
}
