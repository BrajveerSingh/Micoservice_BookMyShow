package com.sapient.theatresservice.model;

import java.util.List;

public record SeatInventoryUpdateRequest(List<String> seats) {
}
