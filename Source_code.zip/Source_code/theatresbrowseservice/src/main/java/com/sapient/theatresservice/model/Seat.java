//package com.sapient.theatresservice.model;
//
////import com.fasterxml.jackson.annotation.JsonIgnore;
////import jakarta.persistence.*;
//
////@Entity
//public class Seat {
////    @Id
////    @GeneratedValue
////    private Long id;
////    @JsonIgnore
////    @ManyToOne
////    @JoinColumn(name = "screen_id", referencedColumnName = "id")
////    private Screen screen;
//    private String screenName;
//    private int seatNumber;
//    private boolean reserved;
//    private boolean booked;
//    private double price;
//
//    public Seat() {
//    }
//
//    public Seat(int seatNumber, double price, String screenName){
//        this.screenName = screenName;
//        this.price = price;
//        this.seatNumber = seatNumber;
//    }
//
//    public boolean isReserved() {
//        return reserved;
//    }
//
//    public void setReserved(boolean reserved) {
//        this.reserved = reserved;
//    }
//
//    public boolean isBooked() {
//        return booked;
//    }
//
//    public void setBooked(boolean booked) {
//        this.booked = booked;
//    }
//
//    public double getPrice() {
//        return price;
//    }
//
//    public void setPrice(double price) {
//        this.price = price;
//    }
//
//    public int getSeatNumber() {
//        return seatNumber;
//    }
//
//    public void setSeatNumber(int seatNumber) {
//        this.seatNumber = seatNumber;
//    }
//
//    public String getScreenName() {
//        return screenName;
//    }
//
//    public void setScreenName(String screenName) {
//        this.screenName = screenName;
//    }
//
//    @Override
//    public String toString() {
//        return "Seat{" +
//                "screenName='" + screenName + '\'' +
//                ", seatNumber=" + seatNumber +
//                ", reserved=" + reserved +
//                ", booked=" + booked +
//                ", price=" + price +
//                '}';
//    }
//}
