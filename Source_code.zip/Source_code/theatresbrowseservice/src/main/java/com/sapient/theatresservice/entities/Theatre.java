package com.sapient.theatresservice.entities;


//import com.sapient.theatresservice.model.Seat;
import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

import java.util.Date;
import java.util.List;
import java.util.Map;

@Entity
public class Theatre {
    @Id
    @GeneratedValue
    private Long id;
    private String country;
    private String city;
    private String address;
    private String name;
    private List<String> movies;
    private List<String> screens;
//    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd-MM-yyyy hh:mm:ss")
//    private List<Date> showTimes;
    private List<String> seatNumbers;

    public Theatre() {
    }

    public Theatre(String country, String city, String address, String name, List<String> movies, List<String> screens, List<String> seatNumbers) {
        this.country = country;
        this.city = city;
        this.address = address;
        this.name = name;
        this.movies = movies;
        this.screens = screens;
        this.seatNumbers = seatNumbers;
    }

    public List<String> getSeatNumbers() {
        return seatNumbers;
    }

    public void setSeatNumbers(List<String> seatNumbers) {
        this.seatNumbers = seatNumbers;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getMovies() {
        return movies;
    }

    public void setMovies(List<String> movies) {
        this.movies = movies;
    }

    public List<String> getScreens() {
        return screens;
    }

    public void setScreens(List<String> screens) {
        this.screens = screens;
    }

    public Long getId() {
        return id;
    }

    @Override
    public String toString() {
        return "Theatre{" +
                "id=" + id +
                ", country='" + country + '\'' +
                ", city='" + city + '\'' +
                ", address='" + address + '\'' +
                ", name='" + name + '\'' +
                ", movies=" + movies +
                ", screens=" + screens +
                '}';
    }

    //
//    @OneToMany(fetch = FetchType.EAGER, mappedBy = "theatre", cascade = CascadeType.MERGE)
//    private List<Screen> screens;
//    @OneToMany(fetch = FetchType.EAGER, mappedBy = "theatre", cascade = CascadeType.MERGE)
//    private List<Movie> movies;
//
//    @OneToMany(fetch = FetchType.EAGER, mappedBy = "theatre", cascade = CascadeType.MERGE)
//    private List<Show> shows;
//
//    public Theatre() {
//    }
//
//    public Theatre(String country, String city, String address, List<Screen> screens, String name) {
//        this.country = country;
//        this.city = city;
//        this.address = address;
//        this.screens = screens;
//        this.name = name;
//    }
//
//    public List<Screen> getScreens() {
//        return screens;
//    }
//
//    public void setScreens(List<Screen> screens) {
//        this.screens = screens;
//    }
//
//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public String getCountry() {
//        return country;
//    }
//
//    public void setCountry(String country) {
//        this.country = country;
//    }
//
//    public String getCity() {
//        return city;
//    }
//
//    public void setCity(String city) {
//        this.city = city;
//    }
//
//    public String getAddress() {
//        return address;
//    }
//
//    public void setAddress(String address) {
//        this.address = address;
//    }
//
//    public List<Movie> getMovies() {
//        return movies;
//    }
//
//    public void setMovies(List<Movie> movies) {
//        this.movies = movies;
//    }
//
//    public Long getId() {
//        return id;
//    }
//
//    public List<Show> getShows() {
//        return shows;
//    }
//
//    public void setShows(List<Show> shows) {
//        this.shows = shows;
//    }

}
