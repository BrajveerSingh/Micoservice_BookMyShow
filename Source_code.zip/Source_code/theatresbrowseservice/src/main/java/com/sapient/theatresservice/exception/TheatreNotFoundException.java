package com.sapient.theatresservice.exception;

public class TheatreNotFoundException extends RuntimeException {
    public TheatreNotFoundException(String message) {
        super(message);
    }
    public TheatreNotFoundException(String message, Throwable throwable) {
        super(message, throwable);
    }
}
