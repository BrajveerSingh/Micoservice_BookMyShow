package com.sapient.theatresservice.service;

import com.sapient.theatresservice.entities.Theatre;
import com.sapient.theatresservice.model.SeatInventoryUpdateRequest;
import com.sapient.theatresservice.model.TheatreCreationRequest;

import java.util.Date;
import java.util.List;

public interface TheatresService {
    List<Theatre> getTheatres(String movieTitle, String country, String city, Date date);

    Theatre createTheatre(TheatreCreationRequest request);

    Theatre updateSeatInventory(Long theatreId, Long screenId, SeatInventoryUpdateRequest request);

    List<Theatre> getTheatres(String city);

    List<Theatre> getTheatres(String movieTitle, String country, String city);
}
