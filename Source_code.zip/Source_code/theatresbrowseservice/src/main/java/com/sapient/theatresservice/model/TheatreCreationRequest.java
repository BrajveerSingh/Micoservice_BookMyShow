package com.sapient.theatresservice.model;

import java.util.Date;
import java.util.List;

public record TheatreCreationRequest(String name, String country, String city, String address, List<String> movies, List<String> screens, List<String> seatNumbers) {
}
