package com.sapient.theatresservice.service;

//import com.sapient.theatresservice.entities.Screen;
//import com.sapient.theatresservice.entities.Show;

import com.sapient.theatresservice.entities.Theatre;
import com.sapient.theatresservice.exception.TheatreNotFoundException;
import com.sapient.theatresservice.model.SeatInventoryUpdateRequest;
import com.sapient.theatresservice.model.TheatreCreationRequest;
import com.sapient.theatresservice.repository.TheatreRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class TheatresServiceImpl implements TheatresService {
    private static final Logger LOGGER = LoggerFactory.getLogger(TheatresServiceImpl.class);
    private final TheatreRepository theatreRepository;

    public TheatresServiceImpl(TheatreRepository theatreRepository) {
        this.theatreRepository = theatreRepository;
    }

    @Override
    public List<Theatre> getTheatres(final String movieTitle, final String country, final String city, final Date date) {
        List<Theatre> theatres =
                theatreRepository.findByCity(city)
                        .orElseThrow(
                                () -> new TheatreNotFoundException(
                                        "No Theatre found for the given city.")
                        );
        return theatres.stream()
                .filter(theatre -> theatre.getMovies().contains(movieTitle))
                .toList();
    }

    @Override
    public Theatre createTheatre(final TheatreCreationRequest request) {
        return theatreRepository.save(
                new Theatre(
                        request.country(),
                        request.city(),
                        request.address(),
                        request.name(),
                        request.movies(),
                        request.screens(),
                        request.seatNumbers()
                )
        );
    }

    @Override
    public Theatre updateSeatInventory(final Long theatreId, final Long screenId, final SeatInventoryUpdateRequest request) {
        Theatre theatre =
                theatreRepository.findById(theatreId)
                        .orElseThrow(
                                () -> new TheatreNotFoundException(
                                        "No theatre found for the given theatre id."));
        theatre.setSeatNumbers(request.seats());
        return theatreRepository.save(theatre);
    }

    @Override
    public List<Theatre> getTheatres(final String city) {
        return theatreRepository.findByCity(city).orElseThrow(() -> new TheatreNotFoundException("No screen found for the given screen id."));
    }

    @Override
    public List<Theatre> getTheatres(final String movieTitle, final String country, final String city) {
        LOGGER.info("movieTitle={} country={}, city={}", movieTitle, country, city);
        Optional<List<Theatre>> byCity = theatreRepository.findByCity(city);
        if (byCity.isPresent()) {
            List<Theatre> theatres = byCity.get();
            List<Theatre> theatreList = theatres.stream().filter(theatre -> theatre.getMovies().contains(movieTitle)).toList();
            LOGGER.info("Returning theatreList={}", theatreList);
            return theatres;
        }
        LOGGER.info("No theatres found");
        return Collections.emptyList();
    }

}
