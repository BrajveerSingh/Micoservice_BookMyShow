//package com.sapient.theatresservice.entities;
//
//import jakarta.persistence.*;
//
//import java.util.List;
//
//@Entity
//public class Movie {
//    @Id
//    @GeneratedValue
//    private Long id;
//    private String title;
//    private String language;
//    @ManyToOne
////    @JoinColumn(name = "theatre_id", nullable = false)
//    private Theatre theatre;
//    @OneToMany(mappedBy = "movie")
//    private List<Show> shows;
//}
