package com.sapient.theatresservice.model;

import java.util.Date;
import java.util.List;
import java.util.Map;

public class TheatreSearchResponse {
    private Long theatreId;
    private String theatreName;
    private Map<String, Date> showStartTimeByMovieTitle;

    public TheatreSearchResponse() {
    }

    public TheatreSearchResponse(Long theatreId, String theatreName, Map<String, Date> showStartTimeByMovieTitle) {
        this.theatreId = theatreId;
        this.theatreName = theatreName;
        this.showStartTimeByMovieTitle = showStartTimeByMovieTitle;
    }

    public Long getTheatreId() {
        return theatreId;
    }

    public String getTheatreName() {
        return theatreName;
    }

    public Map<String, Date> getShowStartTimeByMovieTitle() {
        return showStartTimeByMovieTitle;
    }
}
