//package com.sapient.theatresservice.entities;
//
//import com.fasterxml.jackson.annotation.JsonIgnore;
//import jakarta.persistence.*;
//
//import java.util.List;
//
//@Entity
//public class Screen {
//    @Id
//    @GeneratedValue
//    private Long id;
//
//    private String name;
//
////    @JsonIgnore
//    @ManyToOne
////    @JoinColumn(name = "theatre_id", referencedColumnName = "id")
//    private Theatre theatre;
////    @JsonIgnore
//    @OneToMany(/*fetch = FetchType.EAGER,*/ mappedBy = "screen", cascade = CascadeType.MERGE)
//    private List<Show> shows;
//
//    @OneToMany(/*fetch = FetchType.EAGER, */mappedBy = "screen", cascade = CascadeType.ALL)
//    private List<Seat> seats;
//
//    public Screen() {
//    }
//
//    public Screen(String name, Theatre theatre, List<Show> shows) {
//        this.name = name;
//        this.theatre = theatre;
//        this.shows = shows;
//    }
//
//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public List<Show> getShows() {
//        return shows;
//    }
//
//    public void setShowIds(List<Show> shows) {
//        this.shows = shows;
//    }
//
//    public Long getId() {
//        return id;
//    }
//
//    public Theatre getTheatre() {
//        return theatre;
//    }
//
//    public void setTheatre(Theatre theatre) {
//        this.theatre = theatre;
//    }
//
//    public void setShows(List<Show> shows) {
//        this.shows = shows;
//    }
//
//    public List<Seat> getSeats() {
//        return seats;
//    }
//
//    public void setSeats(List<Seat> seats) {
//        this.seats = seats;
//    }
//}
