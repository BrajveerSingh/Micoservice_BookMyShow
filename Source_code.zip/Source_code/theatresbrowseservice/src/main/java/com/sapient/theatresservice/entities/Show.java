//package com.sapient.theatresservice.entities;
//
//import jakarta.persistence.*;
//
//import java.util.Date;
//
//@Entity
//public class Show {
//    @Id
//    @GeneratedValue
//    private Long id;
//    private String movieName;
//    private Date startTime;
//    private Date endTime;
//    @ManyToOne
////    @JoinColumn(name = "movie_id", nullable = false, referencedColumnName = "id")
//    private Movie movie;
//    @ManyToOne
////    @JoinColumn(name = "screen_id", nullable = false, referencedColumnName = "id")
//    private Screen screen;
//    @ManyToOne
////    @JoinColumn(name = "theatre_id", nullable = false, referencedColumnName = "id")
//    private Theatre theatre;
//
//    public Show() {
//    }
//
//    public Show(String movieName, Date startTime, Date endTime, Screen screen) {
//        this.movieName = movieName;
//        this.startTime = startTime;
//        this.endTime = endTime;
//        this.screen = screen;
//    }
//
//    public String getMovieName() {
//        return movieName;
//    }
//
//    public void setMovieName(String movieName) {
//        this.movieName = movieName;
//    }
//
//    public Date getStartTime() {
//        return startTime;
//    }
//
//    public void setStartTime(Date startTime) {
//        this.startTime = startTime;
//    }
//
//    public Date getEndTime() {
//        return endTime;
//    }
//
//    public void setEndTime(Date endTime) {
//        this.endTime = endTime;
//    }
//
//    public Screen getScreen() {
//        return screen;
//    }
//
//    public void setScreen(Screen screen) {
//        this.screen = screen;
//    }
//
//    public Movie getMovie() {
//        return movie;
//    }
//
//    public void setMovie(Movie movie) {
//        this.movie = movie;
//    }
//
//    public Theatre getTheatre() {
//        return theatre;
//    }
//
//    public void setTheatre(Theatre theatre) {
//        this.theatre = theatre;
//    }
//}
