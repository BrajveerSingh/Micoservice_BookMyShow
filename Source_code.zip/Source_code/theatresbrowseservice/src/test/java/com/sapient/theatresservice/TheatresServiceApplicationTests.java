package com.sapient.theatresservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TheatresServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
