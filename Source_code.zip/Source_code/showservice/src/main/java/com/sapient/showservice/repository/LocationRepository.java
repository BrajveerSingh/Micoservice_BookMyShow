package com.sapient.showservice.repository;

import com.sapient.showservice.entities.Show;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface LocationRepository extends CrudRepository<Show, Long> {
    Optional<List<Show>> findByCity(String city);

    Optional<Show> findByCountryAndCityAndAddress(String country, String city, String address);

    Optional<List<Show>> findByCountryAndCity(String country, String city);

    Optional<Show> findByAddress(String address);
}
