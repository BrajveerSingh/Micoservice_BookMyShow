package com.sapient.showservice.controller;

import com.sapient.showservice.entities.Show;
import com.sapient.showservice.model.ShowCreationRequest;
import com.sapient.showservice.service.ShowService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/shows/v1/")
public class ShowsController {

    private final ShowService locationService;

    public ShowsController(ShowService movieService) {
        this.locationService = movieService;
    }

    @GetMapping("{country}/{city}}")
    public ResponseEntity<List<Show>> getLocations(@PathVariable final String country,
                                                   @PathVariable final String city) {
        return ResponseEntity.ok(locationService.getLocation(country, city));
    }

    @GetMapping("{country}/{city}/{address}")
    public ResponseEntity<Show> getLocation(@PathVariable final String country,
                                            @PathVariable final String city,
                                            @PathVariable final String address) {
        return ResponseEntity.ok(locationService.getLocation(country, city, address));
    }

    @PostMapping
    public ResponseEntity<Show> createMovie(@RequestBody final ShowCreationRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(locationService.create(request));
    }
}
