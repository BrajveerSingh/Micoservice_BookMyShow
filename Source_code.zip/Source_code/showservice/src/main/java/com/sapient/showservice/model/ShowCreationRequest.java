package com.sapient.showservice.model;

import com.sapient.showservice.entities.Seat;

import java.util.Date;
import java.util.List;

public record ShowCreationRequest(Long theatreId, Long movieId, Date showStartTime, Date showEndTime, List<Seat> availableSeats) {
}
