package com.sapient.showservice.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
public class Show {
    @Id
    @GeneratedValue
    private Long id;
    private Long movieId;
    private Long theatreId;

    private Long screenId;
    private Date showStartTime;
    private Date showEndTime;
    private boolean active;
    private List<Seat> availableSeats;
    private List<Seat> bookedSeats = new ArrayList<>();
    private int totalSeats;

    public Show() {
    }

    public Show(Long movieId, Long theatreId, Date showStartTime, Date showEndTime, List<Seat> availableSeats, Long screenId) {
        this.active = true;
        this.availableSeats = new ArrayList<>(availableSeats);
        this.totalSeats = this.availableSeats.size();
        this.showStartTime = showStartTime;
        this.showEndTime = showEndTime;
        this.movieId = movieId;
        this.theatreId = theatreId;
        this.screenId = screenId;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public List<Seat> getAvailableSeats() {
        return availableSeats;
    }

    public void setAvailableSeats(List<Seat> availableSeats) {
        this.availableSeats = availableSeats;
    }

    public List<Seat> getBookedSeats() {
        return bookedSeats;
    }

    public void setBookedSeats(List<Seat> bookedSeats) {
        this.bookedSeats = bookedSeats;
    }

    public Long getId() {
        return id;
    }

    public Long getMovieId() {
        return movieId;
    }

    public Long getTheatreId() {
        return theatreId;
    }

    public Date getShowStartTime() {
        return showStartTime;
    }

    public Date getShowEndTime() {
        return showEndTime;
    }

    public int getTotalSeats() {
        return totalSeats;
    }

    public Long getScreenId() {
        return screenId;
    }
}
