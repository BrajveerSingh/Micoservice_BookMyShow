package com.sapient.showservice.service;

import com.sapient.showservice.entities.Show;
import com.sapient.showservice.model.ShowCreationRequest;

import java.util.List;

public interface ShowService {
    List<Show> getShows(Long theatreId, Long movieId);
    List<Show> getAllShowsRunningInTheatre(Long theatreId);
    List<Show> getShowsRunningMovie(Long movieId);

    Show getShow(Long theatreId, Long movieId);

    Show create(ShowCreationRequest request);

    Show getLocation(String country, String city, String address);
}
