package com.sapient.showservice.model;

public enum SeatType {
    premium,
    regular
}
