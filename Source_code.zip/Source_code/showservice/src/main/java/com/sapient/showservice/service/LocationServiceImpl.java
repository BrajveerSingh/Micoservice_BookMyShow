package com.sapient.showservice.service;

import com.sapient.showservice.entities.Show;
import com.sapient.showservice.exception.LocationNotFoundException;
import com.sapient.showservice.model.ShowCreationRequest;
import com.sapient.showservice.repository.LocationRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LocationServiceImpl implements ShowService {
    private final LocationRepository locationRepository;

    public LocationServiceImpl(LocationRepository movieRepository) {
        this.locationRepository = movieRepository;
    }


    @Override
    public List<Show> getLocation(String country, String city) {
        return locationRepository.findByCountryAndCity(country, city).orElseThrow(() -> new LocationNotFoundException("location not found."));
    }

    @Override
    public Show getLocation(String address) {
        return locationRepository.findByAddress(address).orElseThrow(() -> new LocationNotFoundException("location not found."));
    }

    @Override
    public Show create(final ShowCreationRequest request) {
        return locationRepository.save(new Show(request.country(), request.city(), request.address()));
    }

    @Override
    public Show getLocation(String country, String city, String address) {
        return locationRepository.findByCountryAndCityAndAddress(country, city, address).orElseThrow(() -> new LocationNotFoundException("location not found."));
    }

}
