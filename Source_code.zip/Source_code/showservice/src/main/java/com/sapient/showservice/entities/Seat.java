package com.sapient.showservice.entities;

import com.sapient.showservice.model.SeatType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Seat {
    @Id
    @GeneratedValue
    private Long id;

    private double price;
    private int seatNumber;
    private SeatType seatType;

    private boolean booked;
    private boolean locked;

    public Seat(){

    }

    public Seat(int seatNumber, double price, SeatType seatType) {
        this.price = price;
        this.seatNumber = seatNumber;
        this.seatType = seatType;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public boolean isBooked() {
        return booked;
    }

    public void setBooked(boolean booked) {
        this.booked = booked;
    }

    public boolean isLocked() {
        return locked;
    }

    public void setLocked(boolean locked) {
        this.locked = locked;
    }

    public Long getId() {
        return id;
    }

    public int getSeatNumber() {
        return seatNumber;
    }

    public SeatType getSeatType() {
        return seatType;
    }
}
