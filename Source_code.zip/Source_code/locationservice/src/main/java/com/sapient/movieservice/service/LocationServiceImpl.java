package com.sapient.movieservice.service;

import com.sapient.movieservice.entities.Location;
import com.sapient.movieservice.exception.LocationNotFoundException;
import com.sapient.movieservice.model.LocationCreationRequest;
import com.sapient.movieservice.repository.LocationRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LocationServiceImpl implements LocationService {
    private final LocationRepository locationRepository;

    public LocationServiceImpl(LocationRepository movieRepository) {
        this.locationRepository = movieRepository;
    }


    @Override
    public List<Location> getLocation(String country, String city) {
        return locationRepository.findByCountryAndCity(country, city).orElseThrow(() -> new LocationNotFoundException("location not found."));
    }

    @Override
    public Location getLocation(String address) {
        return locationRepository.findByAddress(address).orElseThrow(() -> new LocationNotFoundException("location not found."));
    }

    @Override
    public Location create(final LocationCreationRequest request) {
        return locationRepository.save(new Location(request.country(), request.city(), request.address()));
    }

    @Override
    public Location getLocation(String country, String city, String address) {
        return locationRepository.findByCountryAndCityAndAddress(country, city, address).orElseThrow(() -> new LocationNotFoundException("location not found."));
    }

}
