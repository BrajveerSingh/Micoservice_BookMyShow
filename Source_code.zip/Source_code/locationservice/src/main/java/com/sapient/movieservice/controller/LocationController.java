package com.sapient.movieservice.controller;

import com.sapient.movieservice.entities.Location;
import com.sapient.movieservice.model.LocationCreationRequest;
import com.sapient.movieservice.service.LocationService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/location/v1/")
public class LocationController {

    private final LocationService locationService;

    public LocationController(LocationService movieService) {
        this.locationService = movieService;
    }

    @GetMapping("{country}/{city}}")
    public ResponseEntity<List<Location>> getLocations(@PathVariable final String country,
                                                       @PathVariable final String city) {
        return ResponseEntity.ok(locationService.getLocation(country, city));
    }

    @GetMapping("{country}/{city}/{address}")
    public ResponseEntity<Location> getLocation(@PathVariable final String country,
                                                @PathVariable final String city,
                                                @PathVariable final String address) {
        return ResponseEntity.ok(locationService.getLocation(country, city, address));
    }

    @PostMapping
    public ResponseEntity<Location> createMovie(@RequestBody final LocationCreationRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(locationService.create(request));
    }
}
