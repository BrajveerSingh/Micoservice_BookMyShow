package com.sapient.movieservice.service;

import com.sapient.movieservice.entities.Location;
import com.sapient.movieservice.model.LocationCreationRequest;

import java.util.List;

public interface LocationService {
    List<Location> getLocation(String country, String city);

    Location getLocation(String address);

    Location create(LocationCreationRequest request);

    Location getLocation(String country, String city, String address);
}
