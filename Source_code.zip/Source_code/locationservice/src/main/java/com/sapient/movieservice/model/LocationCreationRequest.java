package com.sapient.movieservice.model;

public record LocationCreationRequest(String country, String city, String address, double latitude, double longitude) {
}
