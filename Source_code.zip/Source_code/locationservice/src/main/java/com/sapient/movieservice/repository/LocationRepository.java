package com.sapient.movieservice.repository;

import com.sapient.movieservice.entities.Location;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface LocationRepository extends CrudRepository<Location, Long> {
    Optional<List<Location>> findByCity(String city);

    Optional<Location> findByCountryAndCityAndAddress(String country, String city, String address);

    Optional<List<Location>> findByCountryAndCity(String country, String city);

    Optional<Location> findByAddress(String address);
}
