package com.sapient.movieservice.exception;

public class LocationNotFoundException extends RuntimeException {

    public LocationNotFoundException(final String message) {
        super(message);
    }

    public LocationNotFoundException(final String message, final Throwable throwable) {
        super(message, throwable);
    }
}
