package com.sapient.movieservice.service;

import com.sapient.movieservice.entities.Movie;
import com.sapient.movieservice.model.MovieCreationRequest;

import java.util.List;

public interface MovieService {
    List<Movie> getMovies(String title);

    Movie getMovie(String title, String language);

    Movie create(MovieCreationRequest request);

    List<Movie> getMovies(String country, String city);

    List<Movie> getCityMovies(String city);
}
