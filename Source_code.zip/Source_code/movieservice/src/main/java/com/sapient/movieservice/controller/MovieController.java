package com.sapient.movieservice.controller;

import com.sapient.movieservice.entities.Movie;
import com.sapient.movieservice.model.MovieCreationRequest;
import com.sapient.movieservice.service.MovieService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/movies/v1")
public class MovieController {

    private final MovieService movieService;

    public MovieController(MovieService movieService) {
        this.movieService = movieService;
    }

    @GetMapping("/{city}")
    public ResponseEntity<List<Movie>> getCityMovies(@PathVariable final String city) {
        return ResponseEntity.ok(movieService.getCityMovies(city));
    }

    @GetMapping("/{title}/{language}")
    public ResponseEntity<Movie> getMovie(@PathVariable final String title,
                                          @PathVariable final String language) {
        return ResponseEntity.ok(movieService.getMovie(title, language));
    }

    @PostMapping
    public ResponseEntity<Movie> createMovie(@RequestBody final MovieCreationRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(movieService.create(request));
    }
}
