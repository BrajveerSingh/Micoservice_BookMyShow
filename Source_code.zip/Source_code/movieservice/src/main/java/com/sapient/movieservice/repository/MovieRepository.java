package com.sapient.movieservice.repository;

import com.sapient.movieservice.entities.Movie;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface MovieRepository extends CrudRepository<Movie, Long> {
    Optional<List<Movie>> findByTitle(String title);

    Optional<Movie> findByTitleAndLanguage(String title, String language);

    Optional<List<Movie>> findByCountryAndCity(String country, String city);

    Optional<List<Movie>> findByCity(String city);
}
