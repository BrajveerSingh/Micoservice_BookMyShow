package com.sapient.movieservice.model;

public record MovieCreationRequest(String title, String language, String country, String city) {
}
