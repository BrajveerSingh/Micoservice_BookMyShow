package com.sapient.movieservice.service;

import com.sapient.movieservice.entities.Movie;
import com.sapient.movieservice.exception.MovieNotFoundException;
import com.sapient.movieservice.model.MovieCreationRequest;
import com.sapient.movieservice.repository.MovieRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MovieServiceImpl implements MovieService {
    private static final Logger LOGGER = LoggerFactory.getLogger(MovieServiceImpl.class);

    private final MovieRepository movieRepository;

    public MovieServiceImpl(MovieRepository movieRepository) {
        this.movieRepository = movieRepository;
    }

    @Override
    public List<Movie> getMovies(String text) {
        LOGGER.info("movieTitle={}", text);
        List<Movie> movies = movieRepository.findByTitle(text).orElseThrow(() -> new MovieNotFoundException("Unable to find movies."));
        LOGGER.info("Returning movies={}", movies);
        return movies;
    }

    @Override
    public Movie getMovie(String title, String language) {
        LOGGER.info("movieTitle={}, language={}", title, language);
        Movie movie = movieRepository.findByTitleAndLanguage(title, language).orElseThrow(() -> new MovieNotFoundException("Unable to find movies."));
        LOGGER.info("Returning movie={}", movie);
        return movie;
    }
    @Override
    public Movie create(final MovieCreationRequest request) {
        LOGGER.info("Creating movie for request={}", request);
        return movieRepository.save(new Movie(request.title(), request.language(), request.country(), request.city()));
    }

    @Override
    public List<Movie> getMovies(String country, String city) {
        LOGGER.info("country={}, city={}", country, city);
        List<Movie> movies = movieRepository.findByCountryAndCity(country, city)
                .orElseThrow(
                        () -> new MovieNotFoundException("Movie not found for the given city and country")
                );
        LOGGER.info("Returning movies={},", movies);
        return movies;
    }

    @Override
    public List<Movie> getCityMovies(String city) {
        LOGGER.info("city={}", city);
        List<Movie> movies = movieRepository.findByCity(city).orElseThrow(
                () -> new MovieNotFoundException("No movie found for the given city")
        );
        LOGGER.info("Returning movies={}", movies);
        return movies;
    }
}
