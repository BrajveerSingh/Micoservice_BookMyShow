package com.sapient.client.httpinterface;

import com.sapient.client.model.Movie;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.service.annotation.GetExchange;
import org.springframework.web.service.annotation.HttpExchange;
import reactor.core.publisher.Mono;

import java.util.List;

@HttpExchange
public interface MovieServiceClient {
    @GetExchange("/{city}")
    Mono<List<Movie>> getMovies(@PathVariable String city);
}
