package com.sapient.client.exception;

public class MovieNotFoundException extends RuntimeException {

    public MovieNotFoundException(final String message) {
        super(message);
    }

    public MovieNotFoundException(final String message, final Throwable throwable) {
        super(message, throwable);
    }
}
