package com.sapient.client.service;

import com.sapient.client.httpinterface.MovieServiceClient;
import com.sapient.client.httpinterface.TheatreServiceClient;
import com.sapient.client.model.Movie;
import com.sapient.client.model.Theatre;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.List;

@Service
public class ClientServiceImpl implements ClientService {
    private final static Logger LOGGER = LoggerFactory.getLogger(ClientServiceImpl.class);
    private final MovieServiceClient movieServiceClient;
    private final TheatreServiceClient theatreServiceClient;

    public ClientServiceImpl(MovieServiceClient movieServiceClient, TheatreServiceClient theatreServiceClient) {
        this.movieServiceClient = movieServiceClient;
        this.theatreServiceClient = theatreServiceClient;
    }


    @Override
    public Mono<List<Movie>> getMovies(String city) {
        return movieServiceClient.getMovies(city);
    }

    @Override
    public Movie getMovie(String title, String language) {
        throw new UnsupportedOperationException("This method is not supported in current version.");
    }

    @Override
    public Mono<List<Theatre>> getTheatres(String country, String city, String movieTitle) {
        LOGGER.info("country={}, city={}, movieTitle={}",country,city,movieTitle);
        Mono<List<Theatre>> theatres = theatreServiceClient.getTheatres(country, city, movieTitle);
        LOGGER.info("theatres={}",theatres);
        return theatres;
    }

}
