package com.sapient.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public record Theatre(@JsonProperty("id") Long id,
                      @JsonProperty("name") String name,
                      @JsonProperty("movies") List<String> movies,
                      @JsonProperty("screens") List<String> screens,
                      @JsonProperty("seatNumbers") List<String> seatNumbers) {


}
