package com.sapient.client.httpinterface;

import com.sapient.client.model.Theatre;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.service.annotation.GetExchange;
import org.springframework.web.service.annotation.HttpExchange;
import reactor.core.publisher.Mono;

import java.util.List;

@HttpExchange(accept = "application/json", contentType = "application/json")
public interface TheatreServiceClient {
    @GetExchange("/{country}/{city}/{movieTitle}")
    Mono<List<Theatre>> getTheatres(@PathVariable String country, @PathVariable String city, @PathVariable String movieTitle);
}
