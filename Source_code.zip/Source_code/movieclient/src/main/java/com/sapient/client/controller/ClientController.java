package com.sapient.client.controller;

import com.sapient.client.model.Movie;
import com.sapient.client.model.Theatre;
import com.sapient.client.service.ClientService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.List;

@RestController
@RequestMapping("/api/client/v1")
public class ClientController {

    private final ClientService clientService;

    public ClientController(ClientService clientService) {
        this.clientService = clientService;
    }

    @GetMapping("/movies/{city}")
    public ResponseEntity<Mono<List<Movie>>> getMovies(@PathVariable String city){
        return ResponseEntity.ok(clientService.getMovies(city));
    }

    @GetMapping("/theatres/{country}/{city}/{movieTitle}")
    public ResponseEntity<Mono<List<Theatre>>> getTheatres(@PathVariable String country, @PathVariable String city, @PathVariable String movieTitle){
        return ResponseEntity.ok(clientService.getTheatres(country, city, movieTitle));
    }


}
