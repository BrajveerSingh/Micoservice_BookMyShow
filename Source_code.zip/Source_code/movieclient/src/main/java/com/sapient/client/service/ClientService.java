package com.sapient.client.service;

import com.sapient.client.model.Movie;
import com.sapient.client.model.Theatre;
import reactor.core.publisher.Mono;

import java.util.List;

public interface ClientService {
    Mono<List<Movie>> getMovies(String city);

    Movie getMovie(String title, String language);

    Mono<List<Theatre>> getTheatres(String country, String city, String movieTitle);
}
